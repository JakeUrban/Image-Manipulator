class Color : public Source
{
	private:
		int h
}
